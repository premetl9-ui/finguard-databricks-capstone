"""FinGuard AI investigation agent."""
